function EnumerationRepresentation(manager, instanceName) {

;
this.m_Enumeration=null;
;
this.m_EA.Element=null;

/// <summary>
/// Deze functie maakt ook de Enumeration aan.
/// </summary>
/// <param name="enumRep"></param>
this.EnumerationRepresentation = function(enumRep){

};

}//end EnumerationRepresentation



function EnumerationRepresentations(manager, instanceName) {

this.linkingAttributes=null;
this.enumerationRepresentations=null;

/// 
/// <param name="linkingRep"></param>
/// <param name="enumRep"></param>
this.addEnum = function(linkingRep, enumRep){

};

/// 
/// <param name="name"></param>
this.getByName = function(name){

};

/// 
/// <param name="guid"></param>
this.getByLinkingAttributeGUID = function(guid){

};

/// 
/// <param name="linkingRep"></param>
/// <param name="enumRep"></param>
this.findLinkingAttributes = function(linkingRep, enumRep){

};

}//end EnumerationRepresentations





function LInkingAttributes(manager, instanceName) {

;
this.m_EA.Attribute=null;
;
this.m_EnumerationRepresentation=null;

/// 
/// <param name="attribute"></param>
/// <param name="enumRep"></param>
this.AddLinkingAttribute = function(attribute, enumRep){

};

}//end LInkingAttributes



